import time
import json
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from datetime import datetime
import os

# Log dosyasının yolu
LOG_FILE = '/home/bsm/bsm/logs/changes.json'  # Kendi kullanıcı adınıza göre güncelleyin

class ChangeHandler(FileSystemEventHandler):
    def on_any_event(self, event):
        # Olay bilgilerini al
        event_info = {
            'event_type': event.event_type,
            'is_directory': event.is_directory,
            'path': event.src_path,
            'timestamp': datetime.now().isoformat()
        }

        # Log dosyasına yaz
        with open(LOG_FILE, 'a') as f:
            f.write(json.dumps(event_info) + '\n')

if __name__ == "__main__":
    # İzlenecek dizin
    path = '/home/bsm/bsm/test'  # Kendi kullanıcı adınıza göre güncelleyin

    # Log dosyasının var olup olmadığını kontrol et, yoksa oluştur
    if not os.path.exists(LOG_FILE):
        with open(LOG_FILE, 'w') as f:
            json.dump([], f)

    event_handler = ChangeHandler()
    observer = Observer()
    observer.schedule(event_handler, path=path, recursive=True)
    observer.start()
    print(f"Monitoring changes in {path}...")

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()
    observer.join()

